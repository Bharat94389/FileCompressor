import React from 'react';

const Header = () => (
  <div className="head">
      <h1>File Compressor</h1>
  </div>
);

export default Header;