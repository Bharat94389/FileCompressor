import Header from './Components/Header/Header';
import './App.css';
import Upload from './Components/Upload/Upload';
  
const App = () => (
  <div className="App">
    <Header/>
    <Upload/>
  </div>
);

export default App;
